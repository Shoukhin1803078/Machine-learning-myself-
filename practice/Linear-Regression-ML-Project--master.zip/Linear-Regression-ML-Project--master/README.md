# Linear-Regression-ML-Project-
This is a beginner ML project for understanding the ML regression model working principle(Including very very small dataset).
The main aim of this ML project is to give an idea about how ML work.
This ML project only for the beginner, who have no/minimum idea about the working principle of Machine Learning.
